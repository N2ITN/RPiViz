sudo apt-get update
sudo apt-get install libopencv-dev python-opencv
sudo cat requirements.txt | xargs pip install
sudo apt-get install libboost-python-dev
sudo pip install dlib==19.1.0
